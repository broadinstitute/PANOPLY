library(testthat)
library(flipTransformations)

test_check("flipTransformations")
