extern void imodwt(double *Win, double *Vin, int *N, int *j, int *L, 
              double *ht, double *gt, double *Vout);

extern void modwt(double *Vin, int *N, int *j, int *L, double *ht, double *gt, 
             double *Wout, double *Vout);
