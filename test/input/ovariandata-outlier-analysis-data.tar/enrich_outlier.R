library(dplyr)
library(ggplot2)
library(RColorBrewer)
library(reshape2)

setwd('E:/research/ruggles/cptac3/ovarian')

enrich_outlier=function(suffix,direction) {
  
  files=read.table(paste('./sample_input_', suffix,'.txt',sep='',collapse=''),header=F,sep='\t',comment.char="",stringsAsFactors = F)
  clinical=read.table('./CPTAC Ovary Clinical Data_20160915.csv',header=T,sep=',',comment.char="",stringsAsFactors = F)
  clinical=clinical[clinical$Tumor.Grade !='' | clinical$Tumor.Stage..Pathological..Ovary.FIGO.Staging.System!='' ,]

  out_mat=list()
  for (i in 1:nrow(files)) {
    out_mat[[i]]=read.table(paste('./result/', suffix,'/', files[i,2],'_outlier_',direction, '.txt',sep='',collapse=''),header=T,sep='\t',comment.char="",stringsAsFactors = F)
  data=out_mat[[1]]
  names(data)=gsub('X','',names(data))
 ind= match(names(data),clinical$Participant.ID)
 
 phenotype1=clinical$Tumor.Stage..Pathological..Ovary.FIGO.Staging.System[ind]
 phenotype1[grep('Unknown',phenotype1)]=NA
 
 phenotype2=clinical$Tumor.Grade[ind]
 phenotype2[grep('Unknown',phenotype2)]=NA
 phenotype=list(tumor_stage=phenotype1,tumor_grade=phenotype2)
 subtype1=list(t1vs234=c('IC'),t12vs34=c('IC','IIB'),t123vs4=c('IC','IIB','III','IIIA','IIIB','IIIC'))
 subtype2=list(t2vs3x=c('G2'),t23vsx=c('G2','G3'))
 subtype=list(subtype1,subtype2)
 result=matrix(data=NA,nrow=nrow(data),ncol=length(subtype[[1]])+length(subtype[[2]]))
 rownames(result)=data[,1]
 colnames(result)=c(names(subtype[[1]]),names(subtype[[2]]))
 cnt=0
 for (j in 1:length(phenotype)) {
    cur_phenotype=phenotype[[j]]
    for (k in 1:length(subtype[[j]])) {
      cnt=cnt+1
      
   cur_subtype=subtype[[j]][[k]]
   cat('\n',names(subtype[[j]])[k],'\n')
   
 for (m in 1:nrow(data)) {
     if (m%%100==0)
       cat('.')
      if (m%%3000==0)
        cat('.')
     cur_outlier=data[m,!(cur_phenotype %in% cur_subtype) & (!is.na(cur_phenotype)) & cur_phenotype !='']
     other_outlier=data[m,cur_phenotype %in% cur_subtype]
     tab=matrix(c(sum(cur_outlier>0),sum(cur_outlier==0),sum(other_outlier>0),sum(other_outlier==0)),2,2)
     rownames(tab)=c('outlier','not outlier')
     colnames(tab)=c('other',names(subtype[[j]])[k])
     tt=fisher.test(tab,alternative='greater')
     result[m,cnt]=tt$p.value
   }}

 }

 ind=apply(result<0.05,1,sum)>0
 if (sum(ind)) {
 result=result[ind,]
 res_dir=paste('./enrich_result/',suffix,sep='',collaspse='')
  filename=paste(res_dir,'/', files[i,2],'_enrich_',direction, '.txt',sep='',collapse='')
  
  if (!dir.exists(res_dir))
    dir.create(res_dir,recursive=T)
  if (!exists(filename))
    write.table(result,filename,sep='\t',row.names=T,col.names=T) } }}

datanames=c('jhu','pnnl','retro')
directions=c('up')
for (i in 1:length(datanames))
  for (j in 1:length(directions)) 
    enrich_outlier(datanames[i],directions[j])